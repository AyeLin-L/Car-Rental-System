/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rent;
import java.rmi.*;
import java.util.ArrayList;

/**
 *
 * @author Aspire
 */
public interface CRSInterface extends Remote {
    public String Singup(String fname,String lname,String uname,String pwd,String email) throws RemoteException;
    
   public ArrayList<User> ViewCarDetail() throws RemoteException;

   
}


