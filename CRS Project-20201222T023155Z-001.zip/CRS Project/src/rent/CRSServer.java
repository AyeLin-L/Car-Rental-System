/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rent;
import java.rmi.*;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Aspire
 */
public class CRSServer extends UnicastRemoteObject implements CRSInterface{
    public CRSServer() throws RemoteException{
        super();
    }

     public static void main(String[] args) throws RemoteException{
       Registry reg=LocateRegistry.createRegistry(1880);
       CRSServer s=new CRSServer();
       reg.rebind("db",s);
       System.out.println("Server is Running now.......");
   }
    
    /**
     *
     * @param fname
     * @param lname
     * @param uname
     * @param pwd
     * @param email
     * @return
     * @throws RemoteException
     */
    @Override
    public String Singup(String fname, String lname, String uname, String pwd, String email){
    {
        try {
                Class.forName("com.mysql.jdbc.Driver");
                try {
                    Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/crsdb?serverTimezone=UTC", "root","");
                    Statement st=con.createStatement();
                    
                  String sql="insert into client values('"+fname+"','"+lname+"','"+uname+"','"+pwd+"','"+email+"')";
                  st.executeUpdate(sql);
                  
                  
                } catch (SQLException ex) {
                    Logger.getLogger(Register.class.getName()).log(Level.SEVERE, null, ex);
                }
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Register.class.getName()).log(Level.SEVERE, null, ex);
            }
       return "Record Inserted Successfully";
       //To change body of generated methods, choose Tools | Templates.
    }
    }

    
    public ArrayList<User> ViewCarDetail() throws RemoteException{
    {
        
    ArrayList<User> cardetail=new ArrayList<>();
       
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(CRSServer.class.getName()).log(Level.SEVERE, null, ex);
        }
       
            Connection con = null;
               
                
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/crsdb?serverTimezone=UTC", "root","");
        } catch (SQLException ex) {
            Logger.getLogger(CRSServer.class.getName()).log(Level.SEVERE, null, ex);
        }
        String sql="Select * from cardetail";
                     Statement st;
            try {
                st = con.createStatement();
                ResultSet rs = st.executeQuery(sql);
                User user;
                while(rs.next()){
                    user=new User(rs.getString("model"),rs.getString("number"),rs.getString("seat"),rs.getString("priceperday"),rs.getString("mpg"),rs.getString("remark"));
                cardetail.add(user);
                }
            } catch (SQLException ex) {
                Logger.getLogger(CRSServer.class.getName()).log(Level.SEVERE, null, ex);
            }  
        return cardetail;
    }
    }}
   


      
