/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rent;

class User {
private String model,number,seat,priceperday,mpg,remark;
        public User(String model,String number,String seat,String priceperday,String mpg,String remark) {
            this.model=model;
            this.number=number;
            this.seat=seat;
            this.priceperday=priceperday;
            this.mpg=mpg;
            this.remark=remark;
            
        }
        
        public String getmodel(){
            return model;
        }
         public String getnumber(){
            return number;
        }
          public String getseat(){
            return seat;
        }
           public String priceperday(){
            return priceperday;
        }
            public String getmpg(){
            return mpg;
        }
             public String getremark(){
            return remark;
        }
    }

  